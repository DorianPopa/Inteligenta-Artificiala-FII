#pragma once
#include "State.h"
#include <vector>
#include <cstdlib>
#include <ctime>

class Problem
{
private:
	State* initialState;
	std::vector<State*> usedStates;

	bool isStateAlreadyUsed(State* s);
	void printSolutionTrace(State* s);
	void deleteUsedStates();
public:
	Problem(int lm, int lc, int rm, int rc, int bs, int bp);

	void solveBacktracking(State* currentState);
	void solveBacktracking();
	void solveRandom(int maxNumberOfTries);
	void solveDFS(int currentDepth, int maxDepth, State* currentState);
	void solveDFS(int maxDepth);
};

