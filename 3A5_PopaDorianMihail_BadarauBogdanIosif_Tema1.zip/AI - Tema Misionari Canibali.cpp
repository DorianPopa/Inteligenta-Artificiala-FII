// AI - Tema Misionari Canibali.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "State.h"
#include "Problem.h"
#include "Solutie_Bogdan_back.hpp"

using namespace std;

int main() {
	int lm, lc, bs, maxDepth;
	cin >> lm >> lc >> bs >> maxDepth;

	Problem* p = new Problem(lm, lc, 0, 0, bs, 1);

	p->solveBacktracking();
	/*for (int i = 0; i <= 30000; i++)
		p->solveRandom(1000);
	*/
	//p->solveDFS(maxDepth);
	return 0;
}
