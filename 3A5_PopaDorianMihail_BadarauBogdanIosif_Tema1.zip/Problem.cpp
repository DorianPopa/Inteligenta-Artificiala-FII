#include "Problem.h"

Problem::Problem(int lm, int lc, int rm, int rc, int bs, int bp)
{
	initialState = new State(lm, lc, rm, rc, bs, bp);
	usedStates.empty();
	usedStates.push_back(initialState);
}

bool Problem::isStateAlreadyUsed(State* s)
{
	std::vector<State*>::iterator it;
	for (it = usedStates.begin(); it < usedStates.end(); it++) {
		if (**it == *s)
			return true;
	}
	return false;
}

void Problem::solveBacktracking(State* currentState)
{
	usedStates.push_back(currentState);
	if (currentState->isValid()) {
		if (currentState->isFinal()) {
			printSolutionTrace(currentState);
		}
		else {
			for (int peopleToMove = 1; peopleToMove <= initialState->getBoatSize(); peopleToMove++) {
				for (int misToMove = 0; misToMove <= peopleToMove; misToMove++) {
					int canToMove = peopleToMove - misToMove;
					State* nextState = currentState->Transition(misToMove, canToMove);
					if (nextState != nullptr) {
						if (!isStateAlreadyUsed(nextState)) {
							nextState->previousState = currentState;
							solveBacktracking(nextState);
						}
					}
				}
			}
		}
	}

}

void Problem::solveBacktracking()
{
	solveBacktracking(this->initialState);
}

void Problem::printSolutionTrace(State* lastState) {
	std::cout << "Finished\n";
	while (!(lastState == initialState)) {
		lastState->printState();
		lastState = lastState->previousState;
	}
}

void Problem::solveRandom(int maxNumberOfTries)
{
	deleteUsedStates();
	int invalid = 0;

	srand(time(NULL));

	State* currentState = initialState;

	initialState->previousState = initialState;
	while (maxNumberOfTries > 0) {
		int nrPpsToMove = rand() % initialState->getBoatSize() + 1;
		int misToMove = rand() % nrPpsToMove + 1;
		int canToMove = nrPpsToMove - misToMove;

		State* nextState = currentState->Transition(misToMove, canToMove);
		if (nextState != nullptr) {
			if (!isStateAlreadyUsed(nextState)) {
				usedStates.push_back(nextState);
				nextState->previousState = currentState;
				if (nextState->isValid()) {
					invalid = 0;
					if (nextState->isFinal()) {
						printSolutionTrace(nextState);
						break;
					}
					currentState = nextState;
				}
				else	invalid++;
				if (invalid == 3)
					currentState = currentState->previousState;
			}
		}
		maxNumberOfTries--;
	}
}

void Problem::solveDFS(int currentDepth, int maxDepth, State* currentState)
{
	usedStates.push_back(currentState);
	if (currentState->isValid()) {
		if (currentState->isFinal()) {
			printSolutionTrace(currentState);
		}
		else {
			if (currentDepth <= maxDepth) {
				for (int peopleToMove = 1; peopleToMove <= initialState->getBoatSize(); peopleToMove++) {
					for (int misToMove = 0; misToMove <= peopleToMove; misToMove++) {
						int canToMove = peopleToMove - misToMove;
						State* nextState = currentState->Transition(misToMove, canToMove);
						if (nextState != nullptr) {
							if (!isStateAlreadyUsed(nextState)) {
								nextState->previousState = currentState;
								solveDFS(currentDepth + 1, maxDepth, nextState);
							}
						}
					}
				}
			}
		}
	}
}

void Problem::solveDFS(int maxDepth)
{
	solveDFS(1, maxDepth, this->initialState);
}

void Problem::deleteUsedStates()
{
	std::vector<State*>::iterator it;
	for (it = usedStates.begin(); it < usedStates.end(); it++) {
		delete(*it);
	}
	usedStates.clear();
}
